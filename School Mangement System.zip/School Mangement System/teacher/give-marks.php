<?php include('includes/header.php');?>
<?php
if($_SERVER['REQUEST_METHOD'] == "POST"){
	$exam_no = mysqli_real_escape_string($conn, ((int)$_POST['marks_exam']));
	$class_no = mysqli_real_escape_string($conn, ((int)$_POST['marks_class']));
	$subject_no = mysqli_real_escape_string($conn, ((int)$_POST['marks_subject']));
}
/*$sql_early = "INSERT INTO marks (student_no, subject_no,exam_no) VALUES ($student_no, $subject_no,$exam_no);";
$total_pages_sql = "SELECT COUNT(*) FROM subjects";
$result = mysqli_query($conn,$total_pages_sql);
$total_rows = mysqli_fetch_array($result)[0];
while($row = mysqli_fetch_array($result) ){


}*/
$sql_early = "SELECT student_no FROM students WHERE student_class = $class_no;";
$result_ea = mysqli_query($conn, $sql_early);
while($row = mysqli_fetch_array($result_ea) ){
	$student_no = (int)$row['student_no'];
	$sql_big = "SELECT * FROM marks WHERE student_no = $student_no AND subject_no = $subject_no AND exam_no = $exam_no;";
	$res = mysqli_query($conn, $sql_big);
	if(mysqli_num_rows($res)){
		//echo "chole naa";
	}
	else
	{
		$sql_ = "INSERT INTO marks (student_no, subject_no, exam_no) VALUES ($student_no, $subject_no,$exam_no);";
		mysqli_query($conn, $sql_);
		//echo "Hoise!";
	}


}

$selectExam = "SELECT exam_name FROM exams WHERE exam_no = $exam_no;";
$result = mysqli_query($conn, $selectExam);
$exam_name = mysqli_fetch_array($result)[0];

$selectClass = "SELECT class_name FROM classes WHERE class_no = $class_no;";
$result = mysqli_query($conn, $selectClass);
$class_name = mysqli_fetch_array($result)[0];

$selectSubject = "SELECT subject_name FROM subjects WHERE subject_no = $subject_no;";
$result = mysqli_query($conn, $selectSubject);
$subject_name = mysqli_fetch_array($result)[0];

$sqlMarks = "SELECT marks.*,students.student_id, students.student_name FROM marks JOIN students ON marks.student_no = students.student_no WHERE marks.subject_no = $subject_no AND  marks.exam_no = $exam_no ORDER BY mark_no ASC;";
$result = mysqli_query($conn, $sqlMarks);

$count = 1;
?>

<ul class="sidebar navbar-nav">
      <li class="nav-item active">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-home"></i>
          <span>Teacher Home</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="student-view.php">
          <i class="fas fa-book-reader"></i>
          <span>Student</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="subject-view.php">
          <i class="fas fa-book"></i>
          <span>Subject</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="marks-select.php">
          <i class="fas fa-marker"></i>
          <span>Manage Marks</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="books-view.php">
          <i class="fas fa-book-open"></i>
          <span>Library</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="notice-view.php">
          <i class="fas fa-bell"></i>
          <span>Notice Board</span>
        </a>
      </li>

    </ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="select-marks.php">Manage Marks</a>
      </li>
      <li class="breadcrumb-item active">Marks Management</li>
    </ol>
    <!-- Page Content -->
    <h1>Give Marks</h1>
    <hr>
	<center>
	<div class="col-sm-4">
		<div class="card bg-light mb-4" style="max-width: 18rem;">
			<div class="card-body">
				<h4 class="card-title">Marks of <?php echo $exam_name?> Exam</h4>
				<h5 class="card-text">Class: <?php echo $class_name?> </h5>
				<h5 class="card-text">Subject: <?php echo $subject_name?> </h5>
			</div>
		</div>
	</div>
	<div class="card">
		<div class="card-header"><h4>Give Marks</h4></div>
		<table class="table table-bordered">
			<thead>
				<tr>
					<th>#</th>
					<th>ID</th>
					<th>NAME</th>
					<th>MARKS OBTAINED</th>
					<th>COMMENTS</th>
				</tr>
			</thead>
			<tbody>
				<?php while($row = mysqli_fetch_array($result) ){

				$student_id = $row['student_id'];
				$student_name = $row['student_name'];
				
				$mark_no = $row['mark_no'];
				/*$student_no = $row['student_no'];
				$exam_no = $row['exam_no'];
				$class_no = $row['class_no'];
				$subject_no = $row['subject_no'];*/
				$mark = $row['mark'];
				$comment = $row['comment'];
				if(empty($mark) AND empty($comment))
					{$mark = 0;$comment="No Comment";}
				?>
				<!--<input type="hidden" id="student_<?php //echo $student_no; ?>" name="student_no" value="<?php //echo $student_no; ?>">
				<input type="hidden" id="exam_<?php //echo $student_no; ?>" name="exam_no" value="<?php //echo $exam_no; ?>">
				<input type="hidden" id="class_<?php //echo $class_no; ?>" name="class_no" value="<?php //echo $class_no; ?>">
				<input type="hidden" id="subject_<?php //echo $subject_no; ?>" name="subject_no" value="<?php //echo $subject_no; ?>">-->
				<tr>
					<td><?php echo $count; ?></td>
					<td><?php echo $student_id; ?></td>
					<td><?php echo $student_name; ?></td>
					<td>
						<div contentEditable='true' class='edit' id='mark_<?php echo $mark_no; ?>'>
							<?php echo $mark; ?>
						</div>
					</td>
					<td>
						<div contentEditable='true' class='edit' id='comment_<?php echo $mark_no; ?>'>
							<?php echo $comment; ?>
						</div>
					</td>
				</tr>
				<?php
				 $count ++;
				}?>
			</tbody>
		</table>
	</div>
	</center>

    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
<?php include('includes/scripts.php');?>

<script type="text/javascript">
	$(document).ready(function(){
 
 // Add Class
 $('.edit').click(function(){
  $(this).addClass('editMode');
 });

 // Save data
 $(".edit").focusout(function(){
  $(this).removeClass("editMode");
  var id = this.id;
  var split_id = id.split("_");
  var field_name = split_id[0];
  var edit_no = split_id[1];
  var value = $(this).text();

  $.ajax({
   url: '/School Mangement System/admin/update-marks.php',
   type: 'post',
   data: { field:field_name, value:value, no:edit_no },
   success:function(response){
    console.log('Save successfully');
   }
  });
 
 });

});
</script>
<?php include('includes/footer.php');?>