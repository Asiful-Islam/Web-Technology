<?php

$f_name = $l_name = $company = $add1 = $add2 = $city =$state =$zip = $country =$phone = $fax = $email= $d_amount = $o_amount  = $cc_amount= $cc_month= $honour=$name = $a_donation =$add3 = $city2=$state2=$zip2= $comment= $name2 ="";

$f_name_err = $l_name_err = $add1_err = $city_err =$state_err =$zip_err = $country_err =$email_err= $d_amount_err ="";

if($_SERVER['REQUEST_METHOD'] == "POST"){
	if(empty($_POST['f_name'])){
		$f_name_err = "First Name cannot be empty!";
	}
	else{
		$f_name = $_POST['f_name'];
	}
	if(empty($_POST['l_name'])){
		$l_name_err = "Last Name cannot be empty!";
	}
	else{
		$l_name = $_POST['l_name'];
	}
	if(empty($_POST['company'])){
	}
	else{
		$l_name = $_POST['company'];
	}
	if(empty($_POST['add1'])){
		$add1_err = "Address1 cannot be empty!";
	}
	else{
		$add1 = $_POST['add1'];
	}
	if(empty($_POST['add2'])){
	}
	else{
		$add2 = $_POST['add2'];
	}
	if(empty($_POST['city'])){
		$city_err = "city cannot be empty!";
	}
	else{
		$city = $_POST['city'];
	}
	if(empty($_POST['state'])){
		$state_err = "state cannot be empty!";
	}
	else{
		$state = $_POST['state'];
	}
	if(empty($_POST['zip'])){
		$zip_err = "zip cannot be empty!";
	}
	else{
		$zip = $_POST['zip'];
	}
	if(empty($_POST['country'])){
		$country_err = "country cannot be empty!";
	}
	else{
		$country = $_POST['country'];
	}
	if(empty($_POST['phone'])){
	}
	else{
		$phone = $_POST['phone'];
	}
	if(empty($_POST['fax'])){
	}
	else{
		$fax = $_POST['fax'];
	}
	if(empty($_POST['email'])){
		$email_err = "email cannot be empty!";
	}
	else{
		$email = $_POST['email'];
	}
	if(empty($_POST['d_amount'])){
		$d_amount_err = "donation amount cannot be empty!";
	}
	else{
		$d_amount = $_POST['d_amount'];
	}
	if(empty($_POST['o_amount'])){
	}
	else{
		$o_amount = $_POST['o_amount'];
	}
	if(empty($_POST['cc_amount'])){
	}
	else{
		$cc_amount = $_POST['cc_amount'];
	}
	if(empty($_POST['cc_month'])){
	}
	else{
		$cc_month = $_POST['cc_month'];
	}
	if(empty($_POST['honour'])){
	}
	else{
		$honour = $_POST['honour'];
	}
	if(empty($_POST['name'])){
	}
	else{
		$name = $_POST['name'];
	}
	if(empty($_POST['a_donation'])){
	}
	else{
		$a_donation = $_POST['a_donation'];
	}
	if(empty($_POST['add3'])){
	}
	else{
		$add3 = $_POST['add3'];
	}
	if(empty($_POST['city2'])){
	}
	else{
		$city2 = $_POST['city2'];
	}
	if(empty($_POST['state2'])){
	}
	else{
		$state2 = $_POST['state2'];
	}
	if(empty($_POST['zip2'])){
	}
	else{
		$zip2 = $_POST['zip2'];
	}
	if(empty($_POST['comment'])){
	}
	else{
		$comment = $_POST['comment'];
	}
	if(empty($_POST['name2'])){
	}
	else{
		$name2 = $_POST['name2'];
	}

}

?>

<html>
<head>
	<title>Regestraition Form</title>
</head>
<body>
	<p><label style="color: red">*</label>- Denote Required Information</p>
	<h4><label>&gt1.Donation   &gt2.Confirmation   &gtThank You</label></h4>
	<h2 style="color: red">Donor Information</h2>
	<form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
		<div align="center">
		<table>
			<tr>
				<td><label>First Name</label><label style="color:red">*</label></td>
				<td>
					<input type="text" name="f_name" value="<?php echo $f_name; ?>">
					<label style="color:red"><?php echo $f_name_err; ?></label>
				</td>
			<tr>	
				<td><label>Last Name</label><label style="color:red">*</label></td>
				<td>
					<input type="text" name="l_name" value="<?php echo $l_name; ?>">
					<label style="color:red"><?php echo $l_name_err; ?></label>
				</td>
			<tr>
				<td><label>Company</label></td>	
				<td><input type="text" name="company" value="<?php echo $company; ?>"></td>
			</tr>
			<tr>	
				<td><label>Adress1</label><label style="color:red">*</label></td>
				<td>
					<input type="text" name="add1" value="<?php echo $add1; ?>">
					<label style="color:red"><?php echo $add1_err; ?></label>
				</td>
			</tr>
			<tr>	
				<td><label>Address2</label></td>
				<td><input type="text" name="add2" value="<?php echo $add2; ?>"></td>
			</tr>
			<tr>	
				<td><label>City</label><label style="color:red">*</label></td>
				<td>
					<input type="text" name="city" value="<?php echo $city; ?>">
					<label style="color:red"><?php echo $city_err; ?></label>
				</td>	
			</tr>
			<tr>
				<td><label>State</label><label style="color:red">*</label></td>
				<td>
					<select name="state">
						<option value="" <?php if((isset($_POST['state'])) && ($_POST['state']=="")) echo "selected" ?>>Select a State</option>
						<option value="arizona" <?php if((isset($_POST['state'])) && ($_POST['state']=="arizona")) echo "selected" ?>>Arizona</option>
						<option value="california" <?php if((isset($_POST['state'])) && ($_POST['state']=="california")) echo "selected" ?>>California</option>
						<option value="new york" <?php if((isset($_POST['state'])) && ($_POST['state']=="new york")) echo "selected" ?>>New York</option>
					</select>
					<label style="color:red"><?php echo $state_err; ?></label>
				</td>
			</tr>
			<tr>
				<td><label>Zip Code</label><label style="color:red">*</label></td>
				<td>
					<input type="text" name="zip" value="<?php echo $zip; ?>">
					<label style="color:red"><?php echo $zip_err; ?></label>
				</td>
			</tr>
			<tr>
				<td><label>Country</label><label style="color:red">*</label></td>
				<td>
					<select name="country">
						<option value="" <?php if((isset($_POST['country'])) && ($_POST['country']=="")) echo "selected" ?>>Select a Country</option>
						<option value="bangladesh" <?php if((isset($_POST['country'])) && ($_POST['country']=="bangladesh")) echo "selected" ?>>Bangladesh</option>
						<option value="usa" <?php if((isset($_POST['country'])) && ($_POST['country']=="usa")) echo "selected" ?>>United States</option>
						<option value="germany" <?php if((isset($_POST['country'])) && ($_POST['country']=="germany")) echo "selected" ?>>Germany</option>
					</select>
					<label style="color:red"><?php echo $country_err; ?></label>
				</td>
			</tr>
			<tr>	
				<td><label>Phone</label></td>
				<td><input type="text" name="phone" value="<?php echo $phone; ?>"></td>
			</tr>
			<tr>	
				<td><label>Fax</label></td>
				<td><input type="text" name="fax" value="<?php echo $fax; ?>"></td>	
			</tr>
			<tr>	
				<td><label>Email</label><label style="color:red">*</label></td>
				<td>
					<input type="text" name="email" value="<?php echo $email; ?>">
					<label style="color:red"><?php echo $email_err; ?></label>
				</td>	
			</tr>
			<tr>
				<td>
					<label>Donation Amount</label><label style="color:red">*</label>
					<br>
					<small>(Check a button or Type In your amount) </small>
				</td>
				<td>
					<input type="radio" name="d_amount" value="" <?php if((isset($_POST['d_amount'])) && ($_POST['d_amount']=="")) echo "checked" ?>>None
					<input type="radio" name="d_amount" value="$50" <?php if((isset($_POST['d_amount'])) && ($_POST['d_amount']=="$50")) echo "checked" ?>>$50
					<input type="radio" name="d_amount" value="$75" <?php if((isset($_POST['d_amount'])) && ($_POST['d_amount']=="$75")) echo "checked" ?>>$75
					<input type="radio" name="d_amount" value="$100" <?php if((isset($_POST['d_amount'])) && ($_POST['d_amount']=="$100")) echo "checked" ?>>$100
					<input type="radio" name="d_amount" value="$250" <?php if((isset($_POST['d_amount'])) && ($_POST['d_amount']=="$250")) echo "checked" ?>>$250
					<input type="radio" name="d_amount" value="other" <?php if((isset($_POST['d_amount'])) && ($_POST['d_amount']=="other")) echo "checked" ?>>Other
					<label style="color:red"><?php echo $d_amount_err; ?></label>
					<br>
					<label>Other Amount $</label>
					<input type="text" name="o_amount" value="<?php echo $o_amount; ?>">
				</td>
			</tr>
			<tr>
				<td>
					<label>Recurring Donation</label>
					<br>
					<small>(check if yes)</small>
				</td>
				<td>
					<input type="checkbox" name="interested" value="yes"<?php if((isset($_POST['interested'])) && ($_POST['interested']=="yes")) echo "checked" ?>>I am interested in giving on a regular basis.
					<br>
					<label>Monthly Credit Card $</label>
					<input type="text" name="cc_amount" value="<?php echo $cc_amount; ?>">
					<label>For</label>
					<input type="text" name="cc_month" value="<?php echo $cc_month; ?>">
					<label>Months</label>
				</td>
			</tr>
		</table>
	<h2 style="color: red" align="left">Honorarium  and Memorial Donation Information</h2>
		<table>
			<tr>
				<td><b>I would like to make this<br>donation</b></label></td>
				<td>
					<input type="radio" name="honour" value="honour"<?php if((isset($_POST['honour'])) && ($_POST['honour']=="honour")) echo "checked" ?>>To Honor
					<br>
					<input type="radio" name="honour" value="memory" <?php if((isset($_POST['honour'])) && ($_POST['honour']=="memory")) echo "checked" ?>>In Memory of
				</td>
			</tr>
			<tr>
				<td><label>Name</label></td>
				<td><input type="text" name="name" value="<?php echo $name; ?>"></td>
			</tr>
			<tr>
				<td><label>Acknowledge Donation to</label></td>
				<td><input type="text" name="a_donation" value="<?php echo $a_donation; ?>"></td>
			</tr>
			<tr>
				<td><label>Address</label></td>
				<td><input type="text" name="add3" value="<?php echo $add3; ?>"></td>
			</tr>
			<tr>
				<td><label>City</label></td>
				<td><input type="text" name="city2" value="<?php echo $city2; ?>"></td>
			</tr>
			<tr>
				<td><label>State</label></td>
				<td>
					<select name="state2">
						<option value="" <?php if((isset($_POST['state2'])) && ($_POST['state2']=="")) echo "selected" ?>>Select a State</option>
						<option value="arizona" <?php if((isset($_POST['state2'])) && ($_POST['state2']=="arizona")) echo "selected" ?>>Arizona</option>
						<option value="california" <?php if((isset($_POST['state2'])) && ($_POST['state2']=="california")) echo "selected" ?>>California</option>
						<option value="new york" <?php if((isset($_POST['state2'])) && ($_POST['state2']=="new york")) echo "selected" ?>>New York</option>
					</select>
				</td>
			</tr>
			<tr>
				<td><label>Zip</label></td>
				<td><input type="text" name="zip2" value="<?php echo $zip2; ?>"></td>
			</tr>
		</table>
		<h2 style="color: red" align="left">Additional Information</h2>
	</div>
	<p>Please enter your name, company or organization as you would like it to appear in our publications:</p>
	<div align="center">
		<table>
			<tr>
				<td><label>Name</label></td>
				<td><input type="text" name="name2" value="<?php echo $name2; ?>"></td>
			</tr>
		</table>
	</div>
	<input type="checkbox" name="anon" value="anon"<?php if((isset($_POST['anon'])) && ($_POST['anon']=="anon")) echo "checked" ?>>I would like my gift to remain anonymous.<br>
	<input type="checkbox" name="gift" value="gift" <?php if((isset($_POST['gift'])) && ($_POST['anon']=="gift")) echo "checked" ?>>My employer offers a matching gift program.I will mail the matching gift form.<br>
	<input type="checkbox" name="no_mail" value="no_mail" <?php if((isset($_POST['no_mail'])) && ($_POST['no_mail']=="no_mail")) echo "checked" ?>>Please save the cost of acknowledging this gift by not mailing a thank you letter.
	<div align="center">
		<table>
			<tr>
				<td>
					<label>Comments</label>
					<br>
					<small>(Please type any question or feedback here) </small>
				</td>
				<td>
					<textarea rows="4" cols="40" name="address"></textarea>
				</td>
			</tr>
			<tr>
				<td><label>How may we contact you?</label></td>
				<td>
					<input type="checkbox" name="email_co" value="email" <?php if((isset($_POST['email_co'])) && ($_POST['email_co']=="email")) echo "checked" ?>>Email<br>
					<input type="checkbox" name="posmail_co" value="posmail" <?php if((isset($_POST['posmail_co'])) && ($_POST['posmail_co']=="posmail")) echo "checked" ?>>Postal mail<br>
					<input type="checkbox" name="telephone" value="tele" <?php if((isset($_POST['telephone'])) && ($_POST['telephone']=="telephone")) echo "checked" ?>>Telephone<br>
					<input type="checkbox" name="fax_con" value="fax_con" <?php if((isset($_POST['fax_con'])) && ($_POST['fax_con']=="fax_con")) echo "checked" ?>>Fax<br>
				</td>
			</tr>
		</table>
	</div>
	<p>I would like to recieve newssletters and information about special events by:</p>
	<div align="center">
		<table>
			<td>
					<input type="checkbox" name="email_con" value="email" <?php if((isset($_POST['email_con'])) && ($_POST['email_con']=="email")) echo "checked" ?> >Email<br>
					<input type="checkbox" name="posmail_con" value="posmail" <?php if((isset($_POST['posmail_co'])) && ($_POST['posmail_co']=="posmail")) echo "checked" ?>>Postal mail<br>
				</td>
		</table>
	</div>
	<input type="checkbox" name="volun" value="volun" <?php if((isset($_POST['volun'])) && ($_POST['volun']=="volun")) echo "checked" ?>>I would like information about volunteering with the<br>
	<div align="center">
		<input type="reset" name="Reset">
		<input type="submit" name="Continue">
	</div>
	<p>Donate online with confidence. You are on a secure server<br><br>if you have any problems or question, please contact <a href="https//:www.google.com">support</a><label>.</label> </p>
	
	</form>
</body>
</html>