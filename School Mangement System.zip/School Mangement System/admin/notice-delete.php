<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: ../login.php");
}
include "../includes/db_connect.inc.php";

  if(isset($_POST['deletedata'])){
    $id = $_REQUEST['notice_id'];
    $query = "DELETE FROM notices WHERE notice_id='$id'"; 
    $query_run = mysqli_query($conn,$query);
    //$query = "DELETE FROM users WHERE user_name='$id'"; 
    //$query_run = mysqli_query($conn,$query);
  }
  header("Location: notice-view.php");
  if($query_run)
    {
      echo '<script> alert("Data Deleted"); </script>';
      header("location:notice-view.php?pageno=1");
    }
    else
    {
      echo '<script> alert("Data did not Deleted"); </script>';
    }
?>