<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: ../login.php");
}

include "../includes/db_connect.inc.php";

$teacher_id=$teacher_name=$teacher_address=$teacher_merit=$teacher_email=$teacher_phone=$teacher_gender=$teacher_dob=$teacher_jd=$teacher_dept="";

  if(isset($_POST['updatedata'])){
    
    $teacher_id = mysqli_real_escape_string($conn, $_POST['teacher_id']);
    $teacher_name = mysqli_real_escape_string($conn, $_POST['teacher_name']);
    $teacher_address = mysqli_real_escape_string($conn, $_POST['teacher_address']);
    $teacher_merit = mysqli_real_escape_string($conn, $_POST['teacher_merit']);
    $teacher_email = mysqli_real_escape_string($conn, $_POST['teacher_email']);
    $teacher_phone = mysqli_real_escape_string($conn, $_POST['teacher_phone']);
    $teacher_gender = mysqli_real_escape_string($conn, $_POST['teacher_gender']);
    $teacher_dob = mysqli_real_escape_string($conn, $_POST['teacher_dob']);
    $teacher_jd = mysqli_real_escape_string($conn, $_POST['teacher_jd']);
    $teacher_dept = mysqli_real_escape_string($conn, ((int)$_POST['teacher_dept']));
    

    $sql_teacher = "UPDATE teachers SET teacher_name ='$teacher_name', teacher_address ='$teacher_address', teacher_merit ='$teacher_merit',teacher_email='$teacher_email', teacher_phone ='$teacher_phone', teacher_gender ='$teacher_gender',teacher_dob='$teacher_dob',teacher_jd='$teacher_jd',teacher_dept='$teacher_dept' WHERE teacher_id = '$teacher_id';";
    $query_run = mysqli_query($conn, $sql_teacher);

    if($query_run)
    {
      echo '<script> alert("Data Updated"); </script>';
      header("location:teacher-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did Not updated"); </script>';
    }
  }
?>