<?php include('includes/header.php');?>
<?php
  $pageno = $no_of_records_per_page = $offset = $total_rows =$total_pages=0;

  //pagenation code
  if (isset($_GET['pageno'])) {
    $pageno = (int)$_GET['pageno'];
  }
  else {
    $pageno = 1;
  }

  $no_of_records_per_page = 2;
  $offset = ($pageno-1) * $no_of_records_per_page;


  $total_pages_sql = "SELECT COUNT(*) FROM students";
  $result = mysqli_query($conn,$total_pages_sql);
  $total_rows = mysqli_fetch_array($result)[0];
  $total_pages = ceil($total_rows / $no_of_records_per_page);

  //select data
  $sqlStudents = "SELECT student_id, student_name,student_father,student_mother,student_dob,student_email,student_address,  student_phone,student_gender,student_class FROM students LIMIT $offset, $no_of_records_per_page";

  $result = mysqli_query($conn, $sqlStudents);
  $count=1;

?>
<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="dashboard.php">
          <i class="fas fa-home"></i>
          <span>Teacher Home</span>
        </a>
      </li>
     <li class="nav-item active">
        <a class="nav-link" href="student-view.php">
          <i class="fas fa-book-reader"></i>
          <span>Student</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="subject-view.php">
          <i class="fas fa-book"></i>
          <span>Subject</span>
        </a>
      </li>
      <li class="nav-item ">
        <a class="nav-link" href="marks-select.php">
          <i class="fas fa-marker"></i>
          <span>Manage Marks</span>
        </a>
      </li>
     <li class="nav-item ">
        <a class="nav-link" href="books-view.php">
          <i class="fas fa-book-open"></i>
          <span>Library</span>
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="notice-view.php">
          <i class="fas fa-bell"></i>
          <span>Notice Board</span>
        </a>
      </li>

    </ul>

    <!--End of Sidebar-->

  <!-- Scroll to Top Button-->
  <a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
  </a>

  <!-- Logout Modal-->
  <div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
          <button class="close" type="button" data-dismiss="modal" aria-label="Close">
            <span aria-hidden="true">×</span>
          </button>
        </div>
        <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
        <div class="modal-footer">
          <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
          <a class="btn btn-primary" href="login.html">Logout</a>
        </div>
      </div>
    </div>
  </div>

<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="login.html">Logout</a>
      </div>
    </div>
  </div>
</div>
<!-- End Logout Modal-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>

<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>


<!-- End Logout Modal-->

<div id="content-wrapper">
<div class="container-fluid">
  <!-- Breadcrumbs-->
  <ol class="breadcrumb">
    <li class="breadcrumb-item">
      <a href="dashboard.php">Show Student</a>
    </li>
    <li class="breadcrumb-item active">Student Information</li>
  </ol>
  <!-- Page Content -->
  <div class="form-group row">
    <div class="col-sm-11">
      <h1><i class="fas fa-table"></i> Student Information</h1>
    </div>
    <!--<div class="col-sm-1">
      <select class="custom-select my-1 mr-sm-2" name="page_item_no">
        <option value="2">2</option>
        <option value="5">5</option>
        <option value="10" selected>10</option>
        <option value="15">15</option>
      </select>
    </div>-->
  </div>
    <hr>
    <table class="table table-hover table-bordered">
      <thead class="thead-dark">
        <tr>
          <th scope="col">#</th>
          <th scope="col">Student Id</th>
          <th scope="col">Student Name</th>
          <th scope="col">Father Name</th>
          <th scope="col">Mother Name</th>
          <th scope="col">Date Of Birth</th>
          <th scope="col">Email</th>
          <th scope="col">Address</th>
          <th scope="col">Phone</th>
          <th scope="col">Gender</th>
          <th scope="col">Class</th>
         
        </tr>
      </thead>
      <tbody>
        <?php while($row = mysqli_fetch_assoc($result)) { ?>

        <tr>
          <td scope="row"><?php echo $count; ?></td>
          <td><?php echo $row['student_id']; ?></td>
          <td><?php echo $row['student_name']; ?></td>
          <td><?php echo $row['student_father']; ?></td>
          <td><?php echo $row['student_mother']; ?></td>
          <td><?php echo $row['student_dob']; ?></td>
          <td><?php echo $row['student_email']; ?></td>
          <td><?php echo $row['student_address']; ?></td>
          <td><?php echo $row['student_phone']; ?></td>
          <td><?php echo $row['student_gender']; ?></td>
          <td><?php echo $row['student_class']; ?></td>
        </tr>
        <?php $count++; } ?>
      </tbody>
    </table>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
  <?php include('includes/scripts.php');?>

  <!-- Scripts for Modal And Fetching data from table-->


<script type="text/javascript">
$(document).ready( function () {
    $('.table').DataTable();
} );

</script>

<?php include('includes/footer.php');?>
