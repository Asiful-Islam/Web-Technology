<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: /School Mangement System/login.php");
}
include "../includes/db_connect.inc.php";

$exam_id=$exam_name=$exam_date="";

  if(isset($_POST['updatedata'])){
    
    $exam_id = mysqli_real_escape_string($conn, $_POST['exam_id']);
    $exam_name = mysqli_real_escape_string($conn, $_POST['exam_name']);
    $exam_date = mysqli_real_escape_string($conn, $_POST['exam_date']);
   
    

    $sql_exam = "UPDATE exams SET exam_name ='$exam_name', exam_date ='$exam_date' WHERE exam_id = '$exam_id';";
    $query_run = mysqli_query($conn, $sql_exam);

    if($query_run)
    {
      echo '<script> alert("Data Updated"); </script>';
      header("location:exam-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did Not updated"); </script>';
    }
  }
?>