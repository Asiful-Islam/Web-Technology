<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: ../login.php");
}
include "../includes/db_connect.inc.php";

  if(isset($_POST['deletedata'])){
    $id = $_REQUEST['book_id'];
    $query = "DELETE FROM books WHERE book_id='$id'"; 
    $query_run = mysqli_query($conn,$query);
    //$query = "DELETE FROM users WHERE user_name='$id'"; 
    //$query_run = mysqli_query($conn,$query);
  }
  header("Location: books-view.php?pageno=1");
  if($query_run)
    {
      echo '<script> alert("Data Deleted"); </script>';
      header("location:books-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did not Deleted"); </script>';
    }
?>