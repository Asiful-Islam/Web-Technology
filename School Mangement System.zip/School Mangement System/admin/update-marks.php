<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: /School Mangement System/login.php");
}

include "../includes/db_connect.inc.php";

$field = $_POST['field'];
$value = $_POST['value'];
$editno = $_POST['no'];

if($field=="mark"){
$query = "UPDATE marks SET ".$field."= ".(int)$value." WHERE mark_no=".$editno;}
else{
$query = "UPDATE marks SET ".$field."='".$value."' WHERE mark_no=".$editno;}


mysqli_query($conn,$query);

echo 1;
?>