<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: ../login.php");
}
include "../includes/db_connect.inc.php";

  if(isset($_POST['deletedata'])){
    $id = $_REQUEST['student_id'];
    $query = "DELETE FROM students WHERE student_id='$id'"; 
    $query_run = mysqli_query($conn,$query);
    $query = "DELETE FROM users WHERE user_name='$id'"; 
    $query_run = mysqli_query($conn,$query);
  }
  header("Location: student-view.php");
  if($query_run)
    {
      echo '<script> alert("Data Deleted"); </script>';
      header("location:student-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did not Deleted"); </script>';
    }
?>