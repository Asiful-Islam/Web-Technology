<?php
 $u_name="";
 $u_name_err="";
 if($_SERVER['REQUEST_METHOD'] == "POST"){
  if(empty($_POST['u_name'])){
    $u_name_err = " ";
  }
  else{
    $u_name = $_POST['u_name'];
  }
 }
?>


<html>
 <head>
   <title>XYZ</title>
   <link rel="stylesheet" href="./css/style.css">

 </head>


  <body>
     <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
      <div align="center">
         <table>
           <tr>
             <td><label><b>name </label></td>

           </tr>
           <tr>
             <td><input type="text" name="u_name" value="<?php echo $u_name; ?>"></td>
             <label style="color:red"><?php echo $u_name_err; ?></label></td>
           </tr>
          
          
           
           <tr>
     

     <td> <hr></hr><br><input type="submit" value="Submit">
    
    <h2><u>Your Information: </u></h2><br>
    
    <label>Name: <?php echo $u_name; ?></label></td>
     </tr>

         </table>
          
        
        

      </div>
     
    </form>
  </body>
</html>