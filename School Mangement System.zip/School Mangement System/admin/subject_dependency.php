<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: /School Mangement System/login.php");
}
include "../includes/db_connect.inc.php";
if($_POST['no']){
$no=$_POST['no'];
if($no==0){
 echo "<option>Select Subject</option>";
}else{
 $sql_sub ="SELECT subjects_teachers.*, subjects.subject_name FROM subjects_teachers JOIN subjects ON subjects_teachers.subject_no = subjects.subject_no WHERE subjects_teachers.class_no = $no";
 $sql = mysqli_query($conn,$sql_sub);
 while($row = mysqli_fetch_array($sql)){
 echo "<option value='" .$row['subject_no'] . "'>" . $row['subject_name'] . "</option>";
 }
 }
}
?>