
<?php include('includes/header.php');?>
<?php

$notice_id=$notice_title=$notice=$notice_date=$notice_show="";

$result=$messege=$success_messege=$sql_notice=$sql_login="";

$notice_idInDB=$notice_id_err="";

if($_SERVER['REQUEST_METHOD'] == "POST"){

    if((!empty($_POST['notice_id']))&&(!empty($_POST['notice_title']))&& (!empty($_POST['notice']))&& (!empty($_POST['notice_date']))&& (!empty($_POST['notice_show'])))
    {
      $notice_id = mysqli_real_escape_string($conn, $_POST['notice_id']);
      $notice_title = mysqli_real_escape_string($conn, $_POST['notice_title']);
      $notice = mysqli_real_escape_string($conn, $_POST['notice']);
      $notice_date = mysqli_real_escape_string($conn, $_POST['notice_date']);
      $notice_show = mysqli_real_escape_string($conn,(int)$_POST['notice_show']);
      
    }
  


    $sqlUserCheck = "SELECT notice_id FROM notices WHERE notice_id = '$notice_id'";
    $result = mysqli_query($conn, $sqlUserCheck);

    while($row = mysqli_fetch_assoc($result)){
      $notice_idInDB = $row['notice_id'];
    }
    $check=(bool)$notice_idInDB == $notice_id;
    if($notice_idInDB == $notice_id){
      $notice_id_err = "Same notice_id already exists!";
    }
    else
    {
      $sql_notice = "INSERT INTO notices (notice_id, notice_title, notice, notice_date, notice_show) VALUES ('$notice_id', '$notice_title','$notice','$notice_date', $notice_show);";
      $result = mysqli_query($conn, $sql_notice);
      $success_messege = "Data Inserted!";
    }

}



?>

<!--Start of Sidebar-->
<ul class="sidebar navbar-nav">
  <li class="nav-item">
    <a class="nav-link" href="dashboard.php">
      <i class="fas fa-home"></i>
      <span>Admin Home</span>
    </a>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-book-reader"></i>
      <span>Manage Student</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="student-add.php">Admit Student</a>
      <a class="dropdown-item" href="student-view.php?pageno=1">Student Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-chalkboard-teacher"></i>
      <span>Manage Teacher</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="teacher-add.php">Add Teacher</a>
      <a class="dropdown-item" href="teacher-view.php?pageno=1">Teacher Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book"></i>
      <span>Manage Subject</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="subject-add.php">Add Subject</a>
      <a class="dropdown-item" href="subject-view.php?pageno=1">Subject Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown ">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-user-tie"></i>
      <span>Manage Admin</span>
    </a>
    <div class="dropdown-menu " aria-labelledby="pagesDropdown">
      <a class="dropdown-item " href="admin-add.php">Add Admin</a>
      <a class="dropdown-item" href="admin-view.php?pageno=1">Admin Infromation</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-file-alt"></i>
      <span>Manage Exam</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="exam-add.php">Add Exam</a>
      <a class="dropdown-item" href="exam-view.php?pageno=1">Exam Infromation</a>
    </div>
  </li>
  <li class="nav-item">
    <a class="nav-link" href="select-marks.php">
      <i class="fas fa-marker"></i>
      <span>Manage Marks</span>
    </a>
  </li>
  <li class="nav-item dropdown active show">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="true">
      <i class="fas fa-bell"></i>
      <span>Noticeboard</span>
    </a>
    <div class="dropdown-menu show" aria-labelledby="pagesDropdown">
      <a class="dropdown-item active" href="notice-add.php">Add Notice</a>
      <a class="dropdown-item" href="notice-view.php?pageno=1">View Notice</a>
      <a class="dropdown-item" href="notice-archive.php">Archived</a>
    </div>
  </li>
  <li class="nav-item dropdown">
    <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
      <i class="fas fa-book-open"></i>
      <span>Manage Library</span>
    </a>
    <div class="dropdown-menu" aria-labelledby="pagesDropdown">
      <a class="dropdown-item" href="books-add.php">Add Books</a>
      <a class="dropdown-item" href="books-view.php?pageno=1">View Books</a>
    </div>
  </li>
</ul>
<!--End of Sidebar-->
<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
  <i class="fas fa-angle-up"></i>
</a>
<!-- Logout Modal-->
<div class="modal fade" id="logoutModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Ready to Leave?</h5>
        <button class="close" type="button" data-dismiss="modal" aria-label="Close">
        <span aria-hidden="true">×</span>
        </button>
      </div>
      <div class="modal-body">Select "Logout" below if you are ready to end your current session.</div>
      <div class="modal-footer">
        <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
        <a class="btn btn-primary" href="../logout.php">Logout</a>
      </div>
    </div>
  </div>
</div>
<div id="content-wrapper">
  <div class="container-fluid">
    <!-- Breadcrumbs-->
    <ol class="breadcrumb">
      <li class="breadcrumb-item">
        <a href="dashboard.php">Manage Notice</a>
      </li>
      <li class="breadcrumb-item active">Add Notice</li>
    </ol>
    <!-- Page Content -->
    <h1>Add Notice</h1>
    <hr>
    <form role="form" method="post">
      <div class="form-group row">
        <label for="inputText3" class="col-sm-2 col-form-label">Notice Id</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="inputText3" name="notice_id" placeholder="Notice Id" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Notice Title</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="notice_title" placeholder="Notice Title" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Notice</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" name="notice" placeholder="Notice" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Notice Date</label>
        <div class="col-sm-10">
          <input type="date" class="form-control" name="notice_date" placeholder="Notice Date" required>
        </div>
      </div>
      <div class="form-group row">
        <label class="col-sm-2 col-form-label">Show</label>
        <div class="col-sm-10">
          <select class="custom-select" name="notice_show" required>
            <option selected>Show?</option>
            <option value="1">Yes</option>
            <option value="0">No</option>
            
          </select>
        </div>
        </div>
      <div class="form-group row">
        <div class="col-sm-12">
          <button type="submit" class="btn btn-primary">Save</button>
          <span class="text-success"><?php echo $success_messege?></span>
          <span class="text-danger"><?php echo $notice_id_err ?></span>
        </div>
      </div>
    </form>
    <!-- End Page Content -->
  </div>
  <!-- end of /.container-fluid -->
 <?php include('includes/scripts.php');?>
<?php include('includes/footer.php');?>