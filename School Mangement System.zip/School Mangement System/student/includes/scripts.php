  <!-- Bootstrap core JavaScript-->
  <script src="/School Mangement System/bootstrap/vendor/jquery/jquery.min.js"></script>
  <script src="/School Mangement System/bootstrap/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

  <!-- Core plugin JavaScript-->
  <script src="/School Mangement System/bootstrap/vendor/jquery-easing/jquery.easing.min.js"></script>

  <!-- Page level plugin JavaScript-->
  <script src="/School Mangement System/bootstrap/vendor/chart.js/Chart.min.js"></script>
  <script src="/School Mangement System/bootstrap/vendor/datatables/jquery.dataTables.js"></script>
  <script src="/School Mangement System/bootstrap/vendor/datatables/dataTables.bootstrap4.js"></script>

  <!-- Custom scripts for all pages-->
  <script src="/School Mangement System/bootstrap/js/sb-admin.min.js"></script>

  <!-- Demo scripts for this page-->
  <script src="/School Mangement System/bootstrap/js/demo/datatables-demo.js"></script>
  <script src="/School Mangement System/bootstrap/js/demo/chart-area-demo.js"></script>