<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: /School Mangement System/login.php");
}
include "../includes/db_connect.inc.php";

  if(isset($_POST['deletedata'])){
    $subject_no = (int)$_REQUEST['subject_no'];
    $st_no = (int)$_REQUEST['st_no'];
    $query = "DELETE FROM subjects WHERE subject_no=$subject_no;"; 
    $query_run = mysqli_query($conn,$query);
    //$query_d = "DELETE FROM subjects_teachers WHERE subjects_teachers.st_no =$st_no AND subjects_teachers.subject_no=$subject_no;"; 
    //$query_run = mysqli_query($conn,$query_d);
  }
  header("Location: subject-view.php?pageno=1");
  if($query_run)
    {
      echo '<script> alert("Data Deleted"); </script>';
      header("location:subject-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did not Deleted"); </script>';
    }
?>