<?php
session_start();
if(!isset($_SESSION["username"]))
{
  header("Location: ../login.php");
}
include "../includes/db_connect.inc.php";

$book_id=$book_name=$book_author=$book_edition="";

  if(isset($_POST['updatedata'])){
    
    $book_id = mysqli_real_escape_string($conn, $_POST['book_id']);
    $book_name = mysqli_real_escape_string($conn, $_POST['book_name']);
    $book_author = mysqli_real_escape_string($conn, $_POST['book_author']);
    $book_edition = mysqli_real_escape_string($conn, $_POST['book_edition']);
    
    

    $sql_book = "UPDATE books SET book_name ='$book_name', book_author ='$book_author', book_edition ='$book_edition' WHERE book_id = '$book_id';";
    $query_run = mysqli_query($conn, $sql_book);

    if($query_run)
    {
      echo '<script> alert("Data Updated"); </script>';
      header("location:books-view.php?pageno=".$_GET['page']);
    }
    else
    {
      echo '<script> alert("Data did Not updated"); </script>';
    }
  }
?>