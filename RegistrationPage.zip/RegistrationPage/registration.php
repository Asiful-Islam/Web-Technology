
<?php
$u_name=$l_name=$com_name=$add1=$add2=$city=$state=$zcode=$country=$phone=$fax=$email=$amount=$otheramount="";

$u_name_err=$l_name_err=$com_name_err=$add1_err=$add2_err=$city_err=$state_err=$zcode_err=$phone_err=$fax_err=$email_err=$amount_err=$otheramount_err="";

if($_SERVER['REQUEST_METHOD'] == "POST"){
	if(empty($_POST['u_name'])){
		$u_name_err = "First Name cannot be empty!";
	}
	else{
		$u_name = $_POST['u_name'];
	}
	
	if(empty($_POST['l_name'])){
		$l_name_err = "Last Name cannot be empty!";
	}
	else{
		$l_name = $_POST['l_name'];
	}
	
	if(empty($_POST['com_name'])){
		$com_name_err = "Last Name cannot be empty!";
	}
	else{
		$com_name = $_POST['com_name'];
	}
	
	if(empty($_POST['add1'])){
		$add1_err = "Address cannot be empty!";
	}
	else{
		$add1 = $_POST['add1'];
	}
	
	if(empty($_POST['add2'])){
		$add2_err = "Address2 cannot be empty!";
	}
	else{
		$add2 = $_POST['add2'];
	}
	if(empty($_POST['city'])){
		$city_err = "City cannot be empty!";
	}
	else{
		$city = $_POST['city'];
	}
	if(empty($_POST['state'])){
		$state_err = "State cannot be empty!";
	}
	else{
		$state = $_POST['state'];
	}
	
	if(empty($_POST['zcode'])){
		$zcode_err = "zcode cannot be empty!";
	}
	else{
		$zcode = $_POST['zcode'];
	}
	if(empty($_POST['country'])){
		$country_err = "country cannot be empty!";
	}
	else{
		$country = $_POST['country'];
	}
	
	if(empty($_POST['phone'])){
		$phone_err = "Phone cannot be empty!";
	}
	else{
		$phone = $_POST['phone'];
	}
	
	if(empty($_POST['fax'])){
		$fax_err = "Fax cannot be empty!";
	}
	else{
		$fax = $_POST['fax'];
	}
	
	if(empty($_POST['email'])){
		$email_err = "E-mail cannot be empty!";
	}
	else{
		$email = $_POST['email'];
	}
	
	if(empty($_POST['amount'])){
		$amount_err = "amount cannot be empty!";
	}
	else{
		$amount = $_POST['amount'];
	}
	
	if(empty($_POST['otheramount'])){
		
	}
	else{
		$otheramount = $_POST['otheramount'];
	}
	if(empty($_POST['name'])){
	}
	else{
		$name = $_POST['name'];
	}
	if(empty($_POST['ackdonatin'])){
	}
	else{
		$ackdonation = $_POST['ackdonation'];
	}
	if(empty($_POST['add'])){
	}
	else{
		$add = $_POST['add'];
	}
	if(empty($_POST['city'])){
	}
	else{
		$city = $_POST['city'];
	}
	if(empty($_POST['state'])){
	}
	else{
		$state = $_POST['state'];
	}
	if(empty($_POST['zcode'])){
	}
	else{
		$zcode = $_POST['zcode'];
	}
	if(empty($_POST['comment'])){
	}
	else{
		$comment = $_POST['comment'];
	}
	if(empty($_POST['name'])){
	}
	else{
		$name = $_POST['name'];
	}

}

	


?>



<html>
     <head>
	     <title>Registration page</title>
     </head>
	    <body>
	       <h1>Donor Information</h1>
	         <form action="<?php echo htmlspecialchars($_SERVER['PHP_SELF']); ?>" method="POST">
	           <div align="center">
	      <table>
	      <tr>
	        <td><label><b>First </label><label style="color:red">*</label></td>
		    <td><input type="text" name="u_name" value="<?php echo $u_name; ?>">
		    <label style="color:red"><?php echo $u_name_err; ?></label></td>
	      </tr>
	   
	     <tr>
	      <td><label><b>Last Name</label><label style="color:red">*</label></td>
		  <td><input type="text" name="l_name"  value="<?php echo $l_name; ?>">
		  <label style="color:red"><?php echo $l_name_err; ?></label></td>

	     </tr>
	   <br>
	   <tr>
	   <td><label><b>Company</label><label style="color:red">*</label></td>
		  <td><input type="text" name="com_name" value="<?php echo $com_name; ?>">
		     <label style="color:red"><?php echo $com_name_err; ?></label>
			 </td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>Address 1</label><label style="color:red">*</label></td>
		  <td><input type="text" name="add1" value="<?php echo $add1; ?>" >
		  <label style="color:red"><?php echo $add1_err; ?></label>
			 </td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>Address 2</label><label style="color:red">*</label></td>
		  <td><input type="text" name="add2" value="<?php echo $add2; ?>">
		  <label style="color:red"><?php echo $add2_err; ?></label>
		  </td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>City</label><label style="color:red">*</label></td>
		  <td><input type="text" name="city" value="<?php echo $city; ?>">
		  <label style="color:red"><?php echo $city_err; ?></label>
		  </td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>State</label><label style="color:red">*</label></td>
		  <td><select name= "state">
		  <option value=""<?php if((isset($_POST['state'])) && ($_POST['state']=="")) echo "selected" ?>>Select a State</option>
		  <option value="Colorado"<?php if((isset($_POST['state'])) && ($_POST['state']=="Colorado")) echo "selected" ?>>Colorado</option>
		  <option value="california" <?php if((isset($_POST['state'])) && ($_POST['state']=="california")) echo "selected" ?>>California</option>
		  <option value="new york" <?php if((isset($_POST['state'])) && ($_POST['state']=="new york")) echo "selected" ?>>New York</option>
		     </select>
			 <label style="color:red"><?php echo $state_err; ?></label>
			 </td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>Zip Code</label><label style="color:red">*</label></td>
		  <td><input type="text" name="zcode" value="<?php echo $zcode; ?>" >
		  <label style="color:red"><?php echo $zcode_err; ?></label>
		  </td>
	   </tr>
	   <br>
	   
	   <tr>
	   <td><label><b>Country</label><label style="color:red">*</label></td>
		  <td><select name= "country">
		  <option value=""<?php if((isset($_POST['country'])) && ($_POST['country']=="")) echo "selected" ?>>Select a Country</option>
		  <option value="America"<?php if((isset($_POST['country'])) && ($_POST['country']=="America")) echo "selected" ?>>America</option>
		  <option value="Bangladesh" <?php if((isset($_POST['country'])) && ($_POST['country']=="Bangladesh")) echo "selected" ?>>Bangladesh</option>
		  <option value="India" <?php if((isset($_POST['country'])) && ($_POST['country']=="India")) echo "selected" ?>>India</option>
		     </select>
			 <label style="color:red"><?php echo $country_err; ?></label>
			 </td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>Phone</label></td>
		  <td><input type="number" name="phone" value="<?php echo $phone; ?>"> 
		  <label style="color:red"><?php echo $phone_err; ?></label>
		  </td>
	   </tr>
	   <br>
	   
	   <tr>
	   <td><label><b>Fax</label></td>
		  <td><input type="text" name="fax" value="<?php echo $fax; ?>">
		  <label style="color:red"><?php echo $fax_err; ?></label></td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>Email</label><label style="color:red">*</label></td>
		  <td><input type="text" name="email" value="<?php echo $email; ?>">
		  <label style="color:red"><?php echo $email_err; ?></label>
		  </td>
	   </tr>
	   <br>
	   
	   <tr>
	   <td><label><b>Donation Amount</label><label style="color:red">*</label></td>
		  <td><input type="radio" name="amount" value=""<?php if((isset($_POST["amount"]))&&($_POST["amount"]==""))echo "checked"?>>None
		  <input type="radio" name="amount" value="$50"<?php if((isset($_POST["amount"]))&&($_POST["amount"]=="$50"))echo "checked"?>>$50
		  <input type="radio" name="amount" value="$75"<?php if((isset($_POST["amount"]))&&($_POST["amount"]=="$75"))echo "checked"?>>$75
		  <input type="radio" name="amount" value="$100"<?php if((isset($_POST["amount"]))&&($_POST["amount"]=="$100"))echo "checked"?>>$100
		  <input type="radio" name="amount" value="$250"<?php if((isset($_POST["amount"]))&&($_POST["amount"]=="$250"))echo "checked"?>>$250
		  <input type="radio" name="amount" value="Other"<?php if((isset($_POST["amount"]))&&($_POST["amount"]=="Other"))echo "checked"?>>Other
		  <label style="color:red"><?php echo $amount_err; ?></label>
		  </td>
	   </tr>
	   <br>
	   
	   <tr>
	   <td><p>(Check a button or type in your amount)</p>
	   <td><label><b>Other Amount$</label>
		  <input type="number" name="otheramount"></td>
	   </tr>
	   <br>
	   
	    <tr>
	   <td><label><b>Recurring Donation</label></td>
		 <td> <input type="checkbox"<p>I am interested in giving on a regular basis</p></td>
	   </tr>
	   
	   
	   
	   <tr>
	   <td></td>
	   <td><p>(Check if yes)</p>
	   
	   <label><b>Monthly Credit Card $</label>
		  <input type="number" name="ccard" size="10" ><label>For</label>
		  <input type="number" name="month" size="10"><label>Months</label>
		  </td>
	   </tr>
	   <br>
	   <tr>
	    <td>
	 <p style="color:red"><b>Honorarium and Memorial Donation Information</p>  
	   </td>
	   
	   
	   <tr>
	   <td><p>I would like to make this<br> donation</p>
	   <td>
		  <input type="radio" name="honor">To Honor
		  <br>
		  <input type="radio" name="honor">In Memory of
		  </td>
	   </tr>
	   <br>
	   <tr>
	     <td><label><b>Name</label></td>
		  <td><input type="text" name="name"></td>
	   </tr>
	   
	   <tr>
	     <td><label><b>Acknowledge Donation to</label></td>
		  <td><input type="text" name="ackdonation"></td>
	   </tr>
	   <tr>
	   <td><label><b>Address</label></td>
		  <td><input type="text" name="add"></td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>City</label></td>
		  <td><input type="text" name="city"></td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>State</label></td>
		  <td><select>
		  
		  <option>Select a State</option>
		  <option>E</option>
		  <option>H</option>
		  <option>I</option>
		     </select></td>
	   </tr>
	   <br>
	   <tr>
	   <td><label><b>Zip</label></td>
		  <td><input type="text" name="zcode"></td>
	   </tr>
	   <br>
	   
	   <tr>
	   <td>
	 <p style="color:red"><b>Additional Information</p>  
	   </td>
	   </tr>
	   
       <tr>
		
	   <td><label>please enter your name,company or organization as you would like it to appear in our publications:</label></td>
	   </tr>
	   <td></td>
	   <br></br>
	   <tr>
	   <td><label><b>Name</label></td>
		<td><input type="text" name="name"></td>
	   </tr>
	   <br>
	   
	   <tr>
		 <td><input type="checkbox">I would like my gift to remain anonymous.</td>
		</tr>
		<tr>
		 <td><input type="checkbox">My employer offers a matching gift program.I will mail the matching gift form.</td>
		 
		 </tr>
		 <tr>
		 <td><input type="checkbox">Please save the cost of acknowledging this gift by not mailing a thank you letter.</td>
	   </tr>
	   
	   <tr>
	   <td><label><b>Comments</label>
	   <p>(Please type any questions or feedback here)</p></td>
		<td>  <textarea name="message" rows="5" cols="40">
          </textarea>
		  </td>
	   </tr>
	   
	   
	   <tr>
	   <td><p><b>How may we contact you?</p></td>
	     <td><input type="checkbox">E-mail
		 <br>
		 <input type="checkbox">Postal Mail
		 <br>
		 <input type="checkbox">Telephone
	     <br>
		 <input type="checkbox">Fax
		 </td>
	  
	   </tr>
	   
	   <tr>
	   
	   <td><p>I would like to receive newsletters and information about special events by: </p></td>
	   <br></br>
	   <td>
	   <br></br>
		  <input type="checkbox" name="events">E-mail
		  <br>
		  <input type="checkbox" name="events">Postal Mail
		  </td>
	   </tr>
	   
	    <tr>
		 <td><input type="checkbox">I would like information about volunteering with the.</td>
	   </tr>
	   
	   <tr>
	   <td></td>
		 <td><input type="submit" value="Submit">
		 <input type="submit" value="Continue"></td>
	   </tr>
	   
	   </table>
	   
	 
	  </div>
	  
	  <br><br>
		
		<h2><u>Your Information: </u></h2><br>
		
		<label>First Name: <?php echo $u_name; ?></label><br>
		<label>Last Name: <?php echo $l_name; ?></label><br>
		<label>Company: <?php echo $com_name; ?></label><br>
		<label>Address: <?php echo $add1; ?></label><br>
		<label>Address2: <?php echo $add2; ?></label><br>
		<label>City: <?php echo $city; ?></label><br>
		<label>State: <?php echo $state; ?></label><br>
		<label>Zip Code: <?php echo $zcode; ?></label><br>
		<label>Country: <?php echo $country; ?></label><br>
		<label>Phone: <?php echo $phone; ?></label><br>
		<label>Fax: <?php echo $fax; ?></label><br>
		<label>Email: <?php echo $email; ?></label>
		</form>
	 </body>
</html>